# multiplication-table
*Escribe un programa PHP que permita al usuario introducir una cadena que contiene 
números del 1 al 9 separados por comas o con guiones para representar rangos, por ejemplo
3 o 1-9 o 1,3,5,7-9. La aplicación mostrará en pantalla todas las tablas de multiplicar 
de los números solicitados sin duplicados. Las tablas de multiplicar se mostrarán con colores alternados gris y blanco. *

* Valida el formato correcto de la cadena

* Utiliza las estructuras de control que consideres oportunas

* Usa funciones de la librería de string y de array

* Usa tablas HTML para mostrar las tablas de multiplicar

