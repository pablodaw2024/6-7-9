<?php

// Funcion para validar y procesar la cadena
function procesarCadena($cadena) {
    $numeros = [];
    // Elimina espacios en blanco
    $cadena = str_replace(' ', '', $cadena);

    // Divide la cadena en bloques separados por comas
    $partes = explode(',', $cadena);

    // Recorre cada parte
    foreach ($partes as $parte) {
        // Si es un rango sacamos todos los nuemros
        // busca la posicion
        if (strpos($parte, '-') !== false) {
            list($inicio, $fin) = explode('-', $parte);
            // Convertimos los rangos en numeros y los agregamos al array
            $numeros = array_merge($numeros, range((int)$inicio, (int)$fin));
        } else {
            // Si es un numero agregamos al array
            $numeros[] = (int)$parte;
        }
    }

    // Eliminamos duplicados y ordena los numeros
    $numeros = array_unique($numeros);
    sort($numeros);

    return $numeros;
}

// Generamos una tabla de multiplicar en HTML
function generarTablaMultiplicar($numero) {
    echo "<table border='1' cellpadding='10' cellspacing='0' style='margin-bottom: 20px;'>";
    echo "<tr><th colspan='2'>Tabla de multiplicar del $numero</th></tr>";
    for ($i = 1; $i <= 10; $i++) {
        $resultado = $numero * $i;
        // Colores
        $color = ($i % 2 == 0) ? '#f0f0f0' : '#ffffff';
        echo "<tr style='background-color: $color'><td>$numero x $i</td><td>$resultado</td></tr>";
    }
    echo "</table>";
}

// Comprobamos si se ha enviado el formulario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $cadena = $_POST['numeros'];

    // Validamos la cadena
    if (preg_match('/^(\d+(-\d+)?)(,(\d+(-\d+)?))*$/', $cadena)) {
        $numeros = procesarCadena($cadena);
        echo "<h2>Tablas de multiplicar solicitadas:</h2>";
        foreach ($numeros as $numero) {
            generarTablaMultiplicar($numero);
        }
    } else {
        echo "<p style='color:red;'>Cadena no valida. Usa numeros del 1 al 9, separados por comas o guiones</p>";
    }
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tablas de multiplicar</title>
</head>
<body>
    <p>Introduce una cadena con números del 1 al 9 separados por comas o guiones</p>
    <form method="POST" action="">
        <label for="numeros">Números:</label>
        <input type="text" id="numeros" name="numeros" required>
        <button type="submit">Generar Tablas</button>
    </form>
</body
