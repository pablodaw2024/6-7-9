<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dado</title>
</head>
<body>
    <h1>Dado</h1>

    <?php
    // Comprobamoss si el formulario ha sido enviado
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Obtener el numero de tiradas
        $num_tiradas = (int)$_POST["num_tiradas"];

        if ($num_tiradas >= 1) {
            // Creamos un array vacio para almacenar los resultados
            $resultados = [];

            // Inicializamos el array con los numeros de 1 a 6 y con valores de 0
            for ($i = 1; $i <= 6; $i++) {
                $resultados[$i] = 0;
            }

            // Simulamos el lanzamiento del dado
            for ($i = 0; $i < $num_tiradas; $i++) {
                // Generamos un numero aleatorio entre 1 y 6
                $tirada = rand(1, 6);

                // Incrementamos el contador del numero que ha salido
                $resultados[$tirada]++;
            }

            // Mostramos los resultados de las tiradas
            echo "<h2>Resultados:</h2>";
            for ($j = 1; $j <= 6; $j++) {
               echo "Número $j: " . $resultados[$j] . "<br>";
            }
        } else {
            // Mostramos un mensaje de error si el número de tiradas es menor que 1
            echo "<p>Introduce un numero mayor o igual a 1</p>";
        }
    }
    ?>

    <form method="POST" action="">
        <label for="num_tiradas">Introduce cuántas veces quieres tirar el dado (mínimo 1):</label>
        <input type="number" id="num_tiradas" name="num_tiradas" min="1" required>
        <button type="submit">Tirar dado</button>
    </form>
</body>
</html>

