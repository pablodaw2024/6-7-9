# roll-a-dice
*Escribe un programa PHP permita al usuario introducir el número de tiradas de un dado, siempre igual o mayor que 1. El programa simulará el lanzamiento de un dado tantas veces como se indique y mostrará por pantalla las veces que se ha obtenido cada número en orden ascendente.*

Conocimientos:

1. Uso de funciones generación de valores aleatorios
2. Utilización de arrays y funciones de array 
3. Ordenación de arrays

