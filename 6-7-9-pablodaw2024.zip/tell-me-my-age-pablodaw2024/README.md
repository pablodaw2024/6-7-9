# tell-me-my-age
*Escribe un programa PHP que permita al usuario introducir su fecha 
de nacimiento y calcule su edad. La fecha se introduce como una cadena
con el formato “dd/mm/yyyy”. La aplicación debe comprobar que el formato
de la fecha es correcto. También debe de validar los datos para 
asegurarse de que se trata de una fecha válida. Se hará uso de una función
auxiliar para saber si un año es bisiesto. La solución no debe incluir 
funciones de librería de fecha de PHP más allá de la función que devuelve
la fecha del sistema.*

Rama: "tell-me-my-age"

Orientaciones:

1. Estructuras de control variadas

2. Construcción de condiciones lógicas

3. Utilización de funciones de usuario en PHP.

*Utiliza todas las funciones de fecha de PHP que creas útiles para implementar el programa de manera más simple.*

Orientaciones:

1. Uso de funciones de la librería de fecha y tiempo
