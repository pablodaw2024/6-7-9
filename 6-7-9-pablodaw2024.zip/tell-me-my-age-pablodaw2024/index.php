<?php
function esBisiesto($anio) {
    // Si el año es divisible entre 4 y no entre 100, o divisible entre 400, es bisiesto
    return ($anio % 4 == 0 && $anio % 100 != 0) || ($anio % 400 == 0);
}
function validarFecha($fecha) {
    // Dividimos la fecha en partes (dd/mm/yyyy)
    $partes = explode("/", $fecha);
    
    if (count($partes) == 3) {
        $dia = (int)$partes[0];
        $mes = (int)$partes[1];
        $anio = (int)$partes[2];

        // Validamos si la fecha es válida con checkdate()
        if (checkdate($mes, $dia, $anio)) {
            // Validamos que no sea una fecha futura
            $fechaIngresada = mktime(0, 0, 0, $mes, $dia, $anio);
            $fechaActual = time();

            // Comprobamos que la fecha sea menor o igual a la actual
            if ($fechaIngresada <= $fechaActual) {
                return true; // Fecha válida y pasada
            }
        }
    }
    
    return false; // Fecha no valida
}

function calcularEdad($fecha) {
    $partes = explode("/", $fecha);
    $diaNacimiento = (int)$partes[0];
    $mesNacimiento = (int)$partes[1];
    $anioNacimiento = (int)$partes[2];

    $diaActual = date("d");
    $mesActual = date("m");
    $anioActual = date("Y");

    // Calculamos la edad
    $edad = $anioActual - $anioNacimiento;

    // Comprobamos si el cumpleaños no ha pasado en el año actual
    if ($mesActual < $mesNacimiento || ($mesActual == $mesNacimiento && $diaActual < $diaNacimiento)) {
        $edad--;
    }

    return $edad;
}



if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fechaNacimiento = $_POST['fecha'];

    // Validamos la fecha ingresada
    if (validarFecha($fechaNacimiento)) {
        $edad = calcularEdad($fechaNacimiento);

        // Mostramos la edad calculada
        echo "<p>Tu edad es: $edad años</p>";

        list($dia, $mes, $anio) = explode('/', $fechaNacimiento);
        echo "<p>Naciste el día $dia del mes $mes del año $anio.</p>";

        // Comprobamos si el año de nacimiento es bisiesto
        if (esBisiesto($anio)) {
            echo "<p>El año $anio fue un año bisiesto.</p>";
        } else {
            echo "<p>El año $anio no fue un año bisiesto.</p>";
        }
    } else {
        echo "<p>Introduce una fecha válida en formato dd/mm/yyyy o asegúrate de que no sea futura.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calcula tu Edad</title>
</head>
<body>
    <h1>Calcula tu Edad</h1>
    <form method="POST">
        <label for="fecha">Fecha de nacimiento (dd/mm/yyyy):</label>
        <input type="text" id="fecha" name="fecha" required>
        <button type="submit">Calcular Edad</button>
    </form>
</body>
</html>
